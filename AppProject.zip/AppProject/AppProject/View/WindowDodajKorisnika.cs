﻿using System;
namespace AppProject
{
	public partial class WindowDodajKorisnika : Gtk.Window
	{
		public WindowDodajKorisnika() : base(Gtk.WindowType.Toplevel)
		{
			this.Build();
		}
	}
}
